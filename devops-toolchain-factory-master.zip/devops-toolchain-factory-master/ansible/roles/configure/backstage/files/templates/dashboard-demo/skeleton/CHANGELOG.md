## 0.3.0 (2022-10-28)

### Changes (1 change)
- Réorganisation du pipeline : le déploiement en KAL se fait avant la préparation et l'exécution des tests DHO

### Added (4 changes)
- Ajout d'une matrice à deux branches pour exécuter les tests DHO
- Ajout d'une étape d'exécution des tests de sécurité, et d'une étape d'exécution des tests d'exploitabilité
- Ajout de la possibilité de choisir la version du simulateur à installer
- Ajout d'une option pour saisir la version du `Job de tests DHO` et la version du `livrable de tests DHO`

## 0.2.0 (2022-09-28)

### Changes (4 changes)
- Suppression des variables d'environnement `SABR_DEV_HOSTNAME_PREFIX`, `SABR_REC_HOSTNAME_PREFIX` et `SABR_KAL_HOSTNAME_PREFIX`
- Modification de la valeur de la variable d'environnement `SABR_NEXUS_BASE`
- Le label 'ansible0X' est devenu label 'agent0X'
- Réorganisation du pipeline : le déploiement en QA se fait avant la préparation et l'exécution des tests QA

### Added (6 changes)
- Ajout d'un paramètre permettant de renseigner la version du Job de tests QA
- Ajout des variables d'environnement `ANSIBLE_FORCE_COLOR` et `ANSIBLE_STDOUT_CALLBACK` pour améliorer l'affichage du STDOUT Ansible
- Intégration entre Gitlab et Jenkins pour publier sur Gitlab le résultat de l'exécution des pipelines Jenkins
- Création d'un nouveau cluster Jenkins avec des agents qui utilisent dorénavent un utilisateur système Linux appelé _devops_
- Implémentation des étapes _Prepare QA Tests_ et _Run QA Tests_
- Installation du plugin TestNG et publication des resultats des tests QA grâce à ce plugin

## 0.1.0 (2022-08-05)

### Fixed (1 change)

- Changement du _workspace_ des agents _Jenkins_ qui causait l'échec de l'exécution des pipelines

### Changes (1 change)

- Implémentation des etapes _Deploy DEV_, _Deploy QA_ et _Deploy KAL_ du pipeline

### Added (4 changes)

- Ajout des paramètres de construction (build parameters)
- Ajout de la documentation (fichier README.md)
- Ajout du changelog (fichier CHANGELOG.md)
- Creation de la release v0.1.0


## 0.0.1 (2022-07-22)

### Added (3 changes)

- Création de la liaison GitLab - Jenkins
- Création du pipeline vide
- Configuration du cluster Jenkins