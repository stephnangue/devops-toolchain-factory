from fastapi import FastAPI, Header
from pydantic import BaseModel
from typing import Annotated, Union
import jenkins
from jinja2 import Template
import requests
import logging
import http.client
import json

http.client.HTTPConnection.debuglevel = 1

logging.basicConfig(level=logging.DEBUG)
requests_log = logging.getLogger("requests.packages.urllib3")
requests_log.setLevel(logging.DEBUG)
requests_log.propagate = True

class Job(BaseModel):
    name: str
    display_name: Union[str, None] = None
    remote_repository_url: Union[str, None] = None
    remote_repository_credential_id: Union[str, None] = None

class Secret(BaseModel):
    repo: str
    key: str
    value: str

class Dashboard(BaseModel):
    name: str
    grafana_template: str
    grafana_datasource: str

app = FastAPI()

# curl -X POST http://127.0.0.1:8000/job -H 'h-username: system' -H 'h-password: default' -H 'Content-Type: application/json' -d '{"name":"My Tata","display_name":"My toto", "remote_repository_url":"git@gitlab.devopslab.ded.stet:snangue/tata.git", "remote_repository_credential_id":"jenkins-worker-key-id"}'

@app.post("/job")
async def create_job(
    job: Job,
    h_username: Annotated[str, Header()],
    h_password: Annotated[str, Header()],
    h_hostname: Annotated[str, Header()]
):
    server = jenkins.Jenkins("https://"+h_hostname, username=h_username, password=h_password)
    xml_file = open("job_config.xml", "r")
    job_xml_config = xml_file.read()
    xml_file.close
    
    j2_template = Template(job_xml_config)

    data = {
        "display_name": job.display_name,
        "remote_repository_url": job.remote_repository_url,
        "remote_repository_credential_id": job.remote_repository_credential_id
    }

    config = j2_template.render(data)

    server.create_job(job.name, config)

@app.post("/secret")
async def create_secret(
    secret: Secret,
    h_token: Annotated[str, Header()],
    h_port: Annotated[str, Header()],
    h_hostname: Annotated[str, Header()],
    h_cacert: Annotated[str, Header()]
):
    url_post = "https://"+h_hostname+":"+h_port+"/v1/secret/data/devops/projects/"+secret.repo+"/repo"

    data = {'data': {'username_jira': secret.key, 'password_jira': secret.value}}

    response = requests.post(url_post, json=data, headers={"X-Vault-Token": h_token}, verify=h_cacert)

@app.post("/dashboard")
async def create_dashboard(
    dashboard: Dashboard,
    h_username: Annotated[str, Header()],
    h_password: Annotated[str, Header()],
    h_port: Annotated[str, Header()],
    h_hostname: Annotated[str, Header()]
): 

    # Retrieve the datasource uid
    url_get = "https://"+h_hostname+":"+h_port+"/api/datasources/name/"+dashboard.grafana_datasource

    try:
        response = requests.get(url_get, headers = {"Content-Type": "application/json"}, auth = (h_username, h_password))
        response.raise_for_status()
        jsonResponse = response.json()

        datasource_uid = jsonResponse["uid"]

    except HTTPError as http_err:
        print(f'HTTP error occurred: {http_err}')
    except Exception as err:
        print(f'Other error occurred: {err}')

    # Open the Grafana template and interpolate it
    template_file = open("dashboards/"+dashboard.grafana_template, "r")
    dashboard_template = template_file.read()
    template_file.close

    j2_template = Template(dashboard_template)

    data = {
        "influxdb_datasource_uid": datasource_uid,
        "project_name": dashboard.name
    }

    json_data = j2_template.render(data)

    # Send a request to create the dashboard
    url_new_db =  "https://"+h_hostname+":"+h_port+"/api/dashboards/db"

    try:
        response = requests.post(url_new_db, json=json.loads(json_data), headers = {"Content-Type": "application/json; charset=UTF-8", "Accept": "application/json" }, auth = (h_username, h_password))
        response.raise_for_status()
        jsonResponse = response.json()
        
        print(jsonResponse)

    except HTTPError as http_err:
        print(f'HTTP error occurred: {http_err}')
    except Exception as err:
        print(f'Other error occurred: {err}')