#!/bin/bash
printf $1'\n'$2 | sudo gitlab-rake gitlab:password:reset[root]