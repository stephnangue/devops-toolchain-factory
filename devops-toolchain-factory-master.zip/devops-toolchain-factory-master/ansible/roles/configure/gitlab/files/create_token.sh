#!/bin/bash
sudo gitlab-rails runner "token = User.find_by_username('root').personal_access_tokens.create(scopes: ['api','read_user', 'read_repository'], name: 'Token for jenkins'); token.set_token('token-for-jenkins001'); token.save!"
sudo gitlab-rails runner "token = User.find_by_username('root').personal_access_tokens.create(scopes: ['api', 'read_api'], name: 'Token for the API'); token.set_token('token-for-read-API01'); token.save!"
sudo gitlab-rails runner "token = User.find_by_username('root').personal_access_tokens.create(scopes: ['api', 'read_user', 'read_repository', 'write_repository'], name: 'Token for Backstage'); token.set_token('token-for-backstage1'); token.save!"
